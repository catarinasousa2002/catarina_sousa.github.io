#include <SI_EFM8BB3_Register_Enums.h>
#include "pwm.h"

static unsigned char duty_percent = 50;              //duty-cycle inicial a 50%
static bit pwm_enabled = 0;                          //se a sa�da PWM est� ativa
static unsigned int pwm_freq = 500;                  //frequ�ncia PWM inicial

static unsigned char xdata sequence_data[PWM_SEQ_MAX_POINTS]; //guardar os pontos da sequ�ncia

static volatile unsigned char sequence_len = 0;      // n de pontos guardados
static volatile unsigned char sequence_index = 0;    //indice do ponto atual da sequ�ncia
static volatile bit seq_playing = 0;                 //indica se a sequ�ncia est� a ser reproduzida
static volatile unsigned char seq_delay = 0;         //delay implementado para tornar a varia��o vis�vel


static bit timer0_set_for_pwm_freq(unsigned int freq)
{
    unsigned long timer0_clk;                        // Frequ�ncia do Timer0
    unsigned long wanted_pca_clk;                    // Frequ�ncia pretendida para o PCA
    unsigned long counts;                            // N�mero de contagens do Timer0
    unsigned char reload;                            // Valor de auto-reload do Timer0

    if ((freq < 100u) || (freq > 1000u))             // S� aceita frequ�ncias entre 100 Hz e 1000 Hz
    {
        return 0;                                    // Frequ�ncia inv�lida
    }

    TCON_TR0 = 0;                                    // Para o Timer0

    TMOD &= ~0x0F;                                   // Limpa a configura��o do Timer0
    TMOD |= 0x02;                                    // Timer0 em modo 2 8-bit auto-reload

    CKCON0 &= ~0x07;                                 
    CKCON0 |= 0x02;                                  // Timer0 usa SYSCLK/48

    timer0_clk = 49000000UL / 48UL;                  // Calcula o clock do Timer0
    wanted_pca_clk = ((unsigned long)freq) * 256UL;  // PCA precisa de 256 contagens por per�odo PWM

    counts = (timer0_clk + (wanted_pca_clk / 2UL)) / wanted_pca_clk; 

    if ((counts < 1UL) || (counts > 256UL))          // Verifica se o valor cabe no Timer0 modo 2
    {
        return 0;                                    // Valor imposs�vel de configurar
    }

    reload = (unsigned char)(256UL - counts);        // Calcula o valor de reload

    TH0 = reload;                                    // Define o reload do Timer0
    TL0 = reload;                                    // Inicializa o Timer0 com o mesmo valor

    pwm_freq = freq;                                 // Guarda a frequ�ncia atual

    TCON_TF0 = 0;                                    // Limpa a flag de overflow do Timer0
    TCON_TR0 = 1;                                    // Arranca o Timer0

    return 1;                                        
}


static void pwm_apply_compare(unsigned char duty)
{
    unsigned char cmp;                               // Valor de compara��o para o PCA

    if (duty > 100)                                  // Limita o duty a 100%
    {
        duty = 100;
    }

    duty_percent = duty;                             // Guarda o duty-cycle atual

    if (duty == 0)                                   // Caso duty seja 0%
    {
        cmp = 0x00;
    }
    else if (duty >= 100)                            // Caso duty seja 100%
    {
        cmp = 0xFF;
    }
    else
    {
        cmp = (unsigned char)(((unsigned int)duty * 255u) / 100u); // Converte percentagem para 8 bits
    }

    PCA0CPL0 = cmp;                                  //byte baixo do comparador
    PCA0CPH0 = cmp;                                  //byte alto do comparador
}


void pwm_sequence_clear(void)
{
    seq_playing = 0;                                 // Para a reprodu��o da sequ�ncia
    sequence_len = 0;                                // Limpa o n�mero de pontos
    sequence_index = 0;                              // Volta ao in�cio da sequ�ncia
    seq_delay = 0;                                   // Limpa o atraso
}


bit pwm_sequence_add_point(unsigned char duty)
{
    if (duty > 100)                                  // S� aceita pontos entre 0% e 100%
    {
        return 0;
    }

    if (sequence_len >= PWM_SEQ_MAX_POINTS)          // Verifica se ainda h� espa�o no array
    {
        return 0;
    }

    sequence_data[sequence_len] = duty;              // Guarda o novo ponto
    sequence_len++;                                  // Incrementa o n�mero de pontos

    return 1;                                        
}


void pca0_pwm_init(void)
{
    PCA0CN0_CR = 0;                                  // Para o PCA durante a configura��o

    timer0_set_for_pwm_freq(500);                    // Configura frequ�ncia inicial de 500 Hz

    PCA0MD = 0x04;                                   // PCA usa overflow do Timer0 como clock

    PCA0CPM0 = 0x42;                                 // M�dulo 0 do PCA em PWM de 8 bits

    PCA0CPM1 = 0x49;                                 // M�dulo 1 usado como temporizador por interrup��o

    PCA0L = 0x00;                                    // Limpa byte baixo do contador PCA
    PCA0H = 0x00;                                    // Limpa byte alto do contador PCA

    PCA0CPL1 = 0x00;                                 // compara��o inicial do m�dulo 1
    PCA0CPH1 = 0x01;                                 // Pr�ximo match ap�s 256 contagens

    PCA0CN0_CF = 0;                                  // Limpa flag de overflow do PCA
    PCA0CN0_CCF1 = 0;                                // Limpa flag de match do m�dulo 1

    EIE1 |= 0x10;                                    // Ativa interrup��o do PCA
    IE_EA = 1;                                       // Ativa interrup��es globais

    pwm_apply_compare(50);                           // Aplica duty-cycle inicial de 50%

    pwm_enabled = 0;                                 // Come�a com a sa�da desligada
    seq_playing = 0;                                 // Sequ�ncia come�a parada
    sequence_index = 0;                              // �ndice inicial da sequ�ncia
    sequence_len = 0;                                // Nenhum ponto carregado inicialmente

    P2 |= 0x01;                                      
}


void pwm_start(void)
{
    PCA0CPM0 = 0x42;                                 // Ativa novamente o m�dulo PWM

    pwm_apply_compare(duty_percent);                 // Aplica o duty-cycle guardado

    PCA0CN0_CR = 1;                                  // Arranca o PCA
    pwm_enabled = 1;                                 // Marca PWM como ativo
}


void pwm_stop(void)
{
    unsigned char saved_duty;                        // Vari�vel auxiliar para guardar o duty

    saved_duty = duty_percent;                       // Guarda o duty atual

    seq_playing = 0;                                 // Para a sequ�ncia, se estiver ativa
    sequence_index = 0;                              // Volta ao in�cio da sequ�ncia
    seq_delay = 0;                                   // Limpa o atraso da sequ�ncia

    PCA0CPM0 = 0x00;                                 // Desliga o m�dulo PWM do PCA
    P2 |= 0x01;                                      

    pwm_enabled = 0;                                 // Marca PWM como desligado
    duty_percent = saved_duty;                       // Mant�m o duty guardado
}


void pwm_set_duty(unsigned char duty)
{
    if (seq_playing)                                 // Durante a sequ�ncia, ignora altera��es de duty
    {
        return;
    }

    pwm_apply_compare(duty);                         // Aplica o novo duty-cycle
}


unsigned char pwm_get_duty(void)
{
    return duty_percent;                             // Devolve o duty-cycle guardado
}


bit pwm_is_on(void)
{
    return pwm_enabled;                              // Devolve se o PWM est� ligado ou desligado
}


bit pwm_set_freq(unsigned int freq)
{
    bit was_on;                                      // Guarda se o PWM estava ligado

    if ((freq < 100u) || (freq > 1000u))             // Valida a gama de frequ�ncia
    {
        return 0;
    }

    if (seq_playing)                                 // Durante a sequ�ncia, ignora altera��o de frequ�ncia
    {
        return 1;
    }

    was_on = pwm_enabled;                            // Guarda o estado anterior do PWM

    PCA0CN0_CR = 0;                                  // Para o PCA para alterar a frequ�ncia

    if (!timer0_set_for_pwm_freq(freq))              // Tenta configurar a nova frequ�ncia
    {
        if (was_on)                                  // Se estava ligado, volta a ligar
        {
            PCA0CN0_CR = 1;
            pwm_enabled = 1;
        }

        return 0;                                    // Erro na configura��o
    }

    PCA0MD = 0x04;                                   // Garante que o PCA continua a usar Timer0 overflow

    pwm_apply_compare(duty_percent);                 //duty-cycle atual

    if (was_on)                                      // Se estava ligado antes, volta a ligar
    {
        PCA0CN0_CR = 1;
        pwm_enabled = 1;
    }
    else
    {
        P2 |= 0x01;                                  // Mant�m sa�da desligada
        pwm_enabled = 0;
    }

    return 1;                                        // Frequ�ncia alterada 
}


bit pwm_sequence_start(void)
{
    if (sequence_len == 0)                           // N�o inicia se n�o houver pontos guardados
    {
        return 0;
    }

    sequence_index = 0;                              // Come�a no primeiro ponto
    seq_delay = 0;                                   // Limpa o atraso
    seq_playing = 1;                                 // Ativa reprodu��o da sequ�ncia

    PCA0CPM0 = 0x42;                                 //m�dulo PWM ativo

    pwm_apply_compare(sequence_data[sequence_index]); // Aplica o primeiro ponto

    sequence_index++;                                // Avan�a para o ponto seguinte

    if (sequence_index >= sequence_len)              // Se chegou ao fim, volta ao in�cio
    {
        sequence_index = 0;
    }

    PCA0CN0_CCF1 = 0;                                // Limpa flag do m�dulo 1
    PCA0CPL1 = PCA0L;                                // Programa pr�ximo match relativo ao contador atual
    PCA0CPH1 = PCA0H + 1;                            // Pr�ximo match daqui a 256 contagens

    PCA0CN0_CR = 1;                                  // Arranca o PCA
    pwm_enabled = 1;                                 // Marca PWM como ativo

    return 1;                                        
}


void pwm_sequence_stop(void)
{
    seq_playing = 0;                                 // Para a reprodu��o da sequ�ncia
    sequence_index = 0;                              // Volta ao in�cio da sequ�ncia
    seq_delay = 0;                                   // Limpa o atraso
}


void PCA0_ISR(void) interrupt 11
{
    if (PCA0CN0_CCF1)                                // Verifica se houve match no m�dulo 1
    {
        PCA0CN0_CCF1 = 0;                            // Limpa a flag do m�dulo 1

        PCA0CPH1++;                                  //pr�ximo match daqui a 256 contagens

        if (seq_playing && (sequence_len > 0))       // S� avan�a se a sequ�ncia estiver ativa
        {
            seq_delay++;                             // Conta interrup��es para diminuir a velocidade da sequ�ncia

            if (seq_delay >= 50)                    // S� muda de ponto a cada 50 interrup��es
            {
                seq_delay = 0;                       // Reinicia o atraso

                pwm_apply_compare(sequence_data[sequence_index]); // Aplica o ponto atual ao PWM

                sequence_index++;                    // Avan�a para o pr�ximo ponto

                if (sequence_index >= sequence_len)  // Se chegou ao fim da sequ�ncia
                {
                    sequence_index = 0;              // Volta ao primeiro ponto
                }
            }
        }
    }

    if (PCA0CN0_CF)                                  // Verifica se houve overflow do PCA
    {
        PCA0CN0_CF = 0;                              // Limpa a flag de overflow
    }
}