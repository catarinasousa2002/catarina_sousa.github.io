#ifndef UART0_H
#define UART0_H
#include <SI_EFM8BB3_Register_Enums.h>

void uart0_init(void);

bit uart0_putchar(unsigned char c);
bit uart0_getchar(unsigned char *c);

void uart0_puts(char *s);
void uart0_put_u8(unsigned char v);

#endif