#ifndef PWM_H
#define PWM_H
#include <SI_EFM8BB3_Register_Enums.h>


#define PWM_SEQ_MAX_POINTS 32

void pca0_pwm_init(void);
void pwm_start(void);
void pwm_stop(void);

void pwm_set_duty(unsigned char duty);
unsigned char pwm_get_duty(void);

bit pwm_is_on(void);
bit pwm_set_freq(unsigned int freq);
bit pwm_sequence_start(void);
void pwm_sequence_stop(void);

void pwm_sequence_clear(void);
bit pwm_sequence_add_point(unsigned char duty);

#endif