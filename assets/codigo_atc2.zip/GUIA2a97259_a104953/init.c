#include <SI_EFM8BB3_Register_Enums.h>
#include "init.h"
#include "uart0.h"

static void init_cpu_clock_49(void)
{
    WDTCN = 0xDE;
    WDTCN = 0xAD;

    CLKSEL = 0x00;
    CLKSEL = 0x00;

    SFRPAGE = 0x10;
    PFE0CN |= (1 << 4);
    SFRPAGE = 0x00;

    CLKSEL |= 0x03;
    CLKSEL |= 0x03;
}

static void init_gpio(void)
{
    // UART0: TX em P0.4 push-pull 
    P0MDOUT |= (1 << 4);

    // PWM CEX0 em P2.0 push-pull 
    P2MDOUT |= (1 << 0);

    /* Crossbar:
       - P0.4 e P0.5 ficam para UART0
       - P2.0 fica para CEX0
    */
    P0SKIP = 0xCF;   // skip P0.0..P0.3 e P0.6..P0.7 
    P1SKIP = 0xFF;   // skip P1 todo 
    P2SKIP = 0xFE;   // deixa s� P2.0 livre 
}

static void init_xbar(void)
{
    XBR0 = 0x01;   // UART0 
    XBR1 = 0x01;   // PCA CEX0 
    XBR2 = 0x40;   // enable crossbar 
}

static void init_timer1_uart0(void)
{
#ifndef _USE_SIMULATOR_
    CKCON0 |= 0x08;      // Timer1 usa SYSCLK 
#endif

    TCON_TR1 = 0;        // stop Timer1 

    TMOD &= ~0xF0;       // limpar configura��o Timer1 
    TMOD |=  0x20;       // Timer1 modo 2: 8-bit auto-reload 

    TH1 = 43;            // 115200 
    TL1 = 43;

    TCON_TR1 = 1;        // start Timer1 
}

static void init_uart0_hw(void)
{
    SCON0 = 0x50;        
    SCON0_TI = 0;
    SCON0_RI = 0;
}

void Init_Device(void)
{
#ifndef USE_SIMULATOR
    init_cpu_clock_49();
#else
    PCA0MD = 0x00;
#endif

    init_gpio();
    init_xbar();
    init_timer1_uart0();
    init_uart0_hw();
    uart0_init();
}