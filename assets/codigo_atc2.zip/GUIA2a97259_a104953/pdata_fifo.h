#ifndef _PDATA_FIFO_MOD_
#define _PDATA_FIFO_MOD_

// comprimento do buffer FIFO, deve ser pot�ncia de 2 para facilitar o uso de m�scara
#define FIFO_LEN (unsigned char) 16   // tamanho do buffer 16

// c�digos de erro e sucesso
#define EXIT_SUCESS 0                 // opera��o realizada com sucesso
#define ENODATA 61                   // erro- n�o h� dados dispon�veis
#define ENOBUFS 105                  // erro- buffer cheio
#define EPERM 1                      // erro- opera��o n�o permitida

typedef unsigned char byte_t;        // defini��o de tipo para um byte

typedef struct virt_fifo
{
		byte_t pdata *p_fifo;        // apontador para o buffer de dados (em mem�ria pdata)
		unsigned char index_write;   // �ndice de escrita no FIFO
		unsigned char index_read;    // �ndice de leitura do FIFO
		unsigned char is_dead;       // flag que indica se FIFO est� desativado
} fifo_t;


/**********************
* @info: initializes a fifo structure
*********************/
extern char fifo_init(fifo_t *p_my_fifo, byte_t pdata *p_buffer);

/**********************
* @info: Writes @parameter to fifo virtual structure
*
* @parameter: a character to be stored
*
* @return: returns number of elements or negative errors
* ENOBUFS or EPERM when fifo not initialized
*********************/
extern int fifo_push_data(fifo_t *p_my_fifo, char element);

/**********************
* @info: removes a value from the fifo
*
* @return: returns the element or negative error ENODATA
*********************/
extern int fifo_pop_data(fifo_t *p_my_fifo);

/**********************
* @info: reads the fifo length
*
* @return: returns the number of elements in the fifo or
* negative error EPERM when fifo not initialized
*********************/
extern int fifo_size(fifo_t *p_my_fifo);

/**********************
* @info: discards the fifo data killing the index positions
*
* @return: returns EXIT_SUCESS
*********************/
//extern char fifo_kill(fifo_t *p_my_fifo);

#endif // _PDATA_FIFO_MOD_