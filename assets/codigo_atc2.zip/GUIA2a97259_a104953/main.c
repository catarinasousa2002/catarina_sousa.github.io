#include <SI_EFM8BB3_Register_Enums.h>
#include "init.h"
#include "protocol.h"
#include "pwm.h"
#include "uart0.h"

void main(void)
{
    Init_Device();
    pca0_pwm_init();
    IE_EA = 1;

    while (1)
    {
        protocol_task();
    }
}

