#include <SI_EFM8BB3_Register_Enums.h>
#include "uart0.h"
#include "pwm.h"
#include "commands.h"
#include "protocol.h"

//  Tamanho do buffer usado para armazenar a tarma recebida
#define RX_SIZE 40

static char frame[RX_SIZE]; //Buffer que vai guardando a tarma caracter a caracter
static unsigned char frame_len = 0;

// FSM principal do protocolo 
typedef enum
{
    PROTOCOL_FRAME,
    PROTOCOL_LOAD_SEQUENCE
} protocol_state_t;

static protocol_state_t protocol_state = PROTOCOL_FRAME;

//  FSM para rececao da trama 
typedef enum
{
    FRAME_WAIT_START,
    FRAME_READ_CC,
    FRAME_READ_REST,
    FRAME_IGNORE
} frame_state_t;

static frame_state_t frame_state = FRAME_WAIT_START;

static unsigned char frame_max_len = 0;    //Comprimento maximo esperado para a trama atual
static unsigned char frame_cc_digits = 0;  //Conta quantos digitos do campo cc ja foram recebidos

static char seq_line[4];                   //Buffer temporario usado para receber cada ponto da sequencia
static unsigned char seq_line_len = 0;		 //Numero de caracteres ja recebidos da atual sequencia
static unsigned char seq_expected = 0;		 //Numero total de pontos esperados na sequencia
static unsigned char seq_received = 0;		 //Numero de pontos ja recebidos na sequencia

//  Verifica se um caracter e um algarismo decimal
static bit is_digit(char c)
{
    return (c >= '0') && (c <= '9');
}

//  Verifica se o caracter corresponde ao de inicio da trama
static bit is_start(char c)
{
    return (c == 'T');
}

//  Converte uma sequencia de caracteres ASCII para inteiros
static bit parse_uint(char *s, unsigned char len, unsigned int *p_val)
{
    unsigned int v;
    unsigned char i;

    if (len == 0)
    {
        return 0;
    }

    v = 0;

    for (i = 0; i < len; i++)
    {
        if (!is_digit(s[i]))
        {
            return 0;
        }

        v = (unsigned int)(v * 10u + (s[i] - '0'));
    }

    *p_val = v;
    return 1;
}

//  Calcula o checksum usado na fase2
static unsigned char calc_checksum(char *f, unsigned char len)
{
    unsigned char i;
    unsigned char cs;

    cs = 0;

    for (i = 0; i < len; i++)
    {
        cs = cs + (unsigned char)f[i];
    }

    return cs;
}

//  Converte um caracter hexadecimal ASCII para o respetivo valor numerico
static int hex_value(char c)
{
    if ((c >= '0') && (c <= '9'))
    {
        return c - '0';
    }

    if ((c >= 'A') && (c <= 'F'))
    {
        return c - 'A' + 10;
    }

    if ((c >= 'a') && (c <= 'f'))
    {
        return c - 'a' + 10;
    }

    return -1;     // Retorna -1 se o caracter nao for hexadecimal
}

//  Converte dois caracteres hexadecimais ASCII num byte
static bit hex_byte(char h, char l, unsigned char *value)
{
    int high;
    int low;

    high = hex_value(h);
    low = hex_value(l);

    if ((high < 0) || (low < 0))
    {
        return 0;
    }

    *value = (unsigned char)((high * 16) + low);

    return 1;
}

//  Executa o comando recebido
static bit run_command(char *cmd, unsigned char len, bit with_checksum)
{
    command_result_t result;
    unsigned char expected;

    expected = 0;

    result = commands_execute(cmd, len, with_checksum, &expected);

    if (result == COMMAND_RESULT_ERR)
    {
        return 0;
    }

    if (result == COMMAND_RESULT_SEQUENCE_LOAD)
    {
        seq_expected = expected;
        seq_received = 0;
        seq_line_len = 0;
        protocol_state = PROTOCOL_LOAD_SEQUENCE;
    }

    return 1;
}

//  Trata um erro ocorrido durante o carregamento da sequencia
static void sequence_error(void)
{
    pwm_sequence_clear();

    seq_line_len = 0;
    seq_expected = 0;
    seq_received = 0;

    protocol_state = PROTOCOL_FRAME;

    commands_send_err();
}

//  Processa os caracteres recebidos durante o carregamento da sequencia
static void sequence_process_char(unsigned char c)
{
    unsigned int value;

    if (c == '\n')
    {
        if (seq_line_len == 0)  //Linha vazia nao e aceite como ponto valido
        {
            sequence_error();
            return;
        }

        seq_line[seq_line_len] = '\0';

        if (!parse_uint(seq_line, seq_line_len, &value))   //Converte a linha recebida para inteiro
        {
            sequence_error();
            return;
        }

        if (value > 100)
        {
            sequence_error();
            return;
        }

        if (!pwm_sequence_add_point((unsigned char)value))
        {
            sequence_error();
            return;
        }

        seq_received++;
        seq_line_len = 0;

        if (seq_received >= seq_expected)   //Quando todos os pontos esperados forem recebidos
        {
            protocol_state = PROTOCOL_FRAME;
            commands_send_ok();
        }

        return;
    }

    if (!is_digit(c))        //Durante a rececao dos pontos, so sao aceites digitos
    {
        sequence_error();
        return;
    }

    if (seq_line_len >= 3)  //Cada ponto so pode ter ate 3 digitos: 0...100
    {
        sequence_error();
        return;
    }

    seq_line[seq_line_len] = (char)c;
    seq_line_len++;
}

//   Valida e processa uma trama completa (no formato apenas da fase2)
static bit process_frame(char *f, unsigned char total_len)
{
    unsigned char cc;
    unsigned char checksum_len;
    unsigned char star_pos;
    unsigned char checksum_calc;
    unsigned char checksum_recv;

    /*
       Fase 2:
       Formato aceite: Tcc<dados>*hh\n

       Checksum usado:
       soma ASCII dos caracteres Tcc<dados>, modulo 256

       Nao entram no calculo:
       - o separador '*'
       - os dois digitos hexadecimais hh
       - o terminador '\n'

       Exemplo com esta formula:
       T04D100 -> checksum = 8D
       trama completa: T04D100*8D\n
    */

    if (total_len < 7)   //Total minimo de uma trama: 7 caracteres
    {
        return 0;
    }

    if (!is_start(f[0]))  //Verifica caracter inicial
    {
        return 0;
    }

    if (!is_digit(f[1]) || !is_digit(f[2]))   //Verifica se cc tem dois digitos
    {
        return 0;
    }

    if (f[total_len - 1] != '\n')      				//Verifica o terminador da trama
    {
        return 0;
    }

    cc = (unsigned char)((f[1] - '0') * 10 + (f[2] - '0'));    //Converte os dois digitos ASCII do comprimento para valor numerico

    /*
       Na Fase 2 a trama tem sempre:
       T + cc + dados + * + hh + \n

       T:      1 caracter
       cc:     2 caracteres
       dados:  cc caracteres
       *:      1 caracter
       hh:     2 caracteres
       \n:     1 caracter

       total = cc + 7
    */
    checksum_len = (unsigned char)(cc + 7);

    //Rejeita tramas antigas da Fase 1
    if (total_len != checksum_len)
    {
        return 0;
    }

    star_pos = (unsigned char)(3 + cc);  // O separador '*' deve aparecer imediatamente depois dos dados

    if (f[star_pos] != '*')
    {
        return 0;
    }
//  Converte os dois caracteres hexadecimais recebidos para o valor numerico do checksum
    if (!hex_byte(f[star_pos + 1], f[star_pos + 2], &checksum_recv))
    {
        return 0;
    }

    /*
       Calcula o checksum apenas sobre Tcc<dados>
       Ou seja, do indice 0 ate ao caracter antes de '*'
    */
    checksum_calc = calc_checksum(f, star_pos);

    if (checksum_calc != checksum_recv)
    {
        return 0;
    }

    return run_command(&f[3], cc, 1);  //Se a trama for valida, executa o comando
}

//  Reset da FSM da trama 
static void frame_reset(void)
{
    frame_state = FRAME_WAIT_START;
    frame_len = 0;
    frame_max_len = 0;
    frame_cc_digits = 0;
    frame[0] = '\0';
}

//  Guarda um caracter no buffer da trama 
static bit frame_add_char(unsigned char c)
{
    if (frame_len >= (RX_SIZE - 1))
    {
        return 0;
    }

    frame[frame_len] = (char)c;
    frame_len++;
    frame[frame_len] = '\0';

    return 1;
}

//  FSM compacta de rececao da trama com state e next_state 
static void frame_process_char(unsigned char c)
{
    frame_state_t next_state;
    unsigned char cc;

    next_state = frame_state;

    switch (frame_state)
    {
        case FRAME_WAIT_START:
            // Espera pelo inicio da trama: 'T' 
            if (is_start(c))
            {
                frame_reset();

                if (!frame_add_char(c))
                {
                    commands_send_err();
                    frame_reset();
                    next_state = FRAME_WAIT_START;
                }
                else
                {
                    next_state = FRAME_READ_CC;
                }
            }
            else if (c != '\n')
            {
                /*
                   Recebeu caracteres fora de uma trama
                   Envia ERR uma vez e ignora o resto da linha
                */
                commands_send_err();
                next_state = FRAME_IGNORE;
            }
            break;

        case FRAME_READ_CC:
            // Le os dois digitos do campo cc 
            if (!is_digit(c))
            {
                commands_send_err();
                frame_reset();
                next_state = FRAME_WAIT_START;
                break;
            }

            if (!frame_add_char(c))
            {
                commands_send_err();
                frame_reset();
                next_state = FRAME_WAIT_START;
                break;
            }

            frame_cc_digits++;

            if (frame_cc_digits == 2)
            {
                cc = (unsigned char)(((frame[1] - '0') * 10) + (frame[2] - '0'));
                frame_max_len = (unsigned char)(cc + 7);

                if ((cc == 0) || (frame_max_len > (RX_SIZE - 1)))
                {
                    commands_send_err();
                    frame_reset();
                    next_state = FRAME_WAIT_START;
                    break;
                }

                next_state = FRAME_READ_REST;
            }
            break;

        case FRAME_READ_REST:
            //  Le o resto da trama ate '\n' 
            if (!frame_add_char(c))
            {
                commands_send_err();
                frame_reset();
                next_state = FRAME_WAIT_START;
                break;
            }

            if (c == '\n')
            {
                if (!process_frame(frame, frame_len))
                {
                    commands_send_err();
                    frame_reset();
                    next_state = FRAME_WAIT_START;
                    break;
                }

                frame_reset();
                next_state = FRAME_WAIT_START;
                break;
            }

            if (frame_len >= frame_max_len)
            {
                commands_send_err();
                frame_reset();
                next_state = FRAME_WAIT_START;
                break;
            }

            break;

        case FRAME_IGNORE:
            
             //  Depois de um erro, ignora caracteres ate ao fim da linha
            
            if (c == '\n')
            {
                frame_reset();
                next_state = FRAME_WAIT_START;
            }
            break;

        default:
            frame_reset();
            next_state = FRAME_WAIT_START;
            break;
    }

    frame_state = next_state;
}

//  Tarefa principal do protocolo
void protocol_task(void)
{
    unsigned char c;

    while (uart0_getchar(&c))
    {
        // Ignora '\r' para aceitar tanto "\n" como "\r\n" 
        if (c == '\r')
        {
            continue;
        }

        if (protocol_state == PROTOCOL_LOAD_SEQUENCE)
        {
            sequence_process_char(c);
            continue;
        }

        frame_process_char(c);
    }
}