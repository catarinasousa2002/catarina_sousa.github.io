#ifndef COMMANDS_H
#define COMMANDS_H
#include <SI_EFM8BB3_Register_Enums.h>

// Resultados poss�veis da execu��o de um comando
typedef enum
{
    COMMAND_RESULT_ERR,
    COMMAND_RESULT_OK,
    COMMAND_RESULT_SEQUENCE_LOAD
} command_result_t;

void commands_send_ok(void);
void commands_send_err(void);

command_result_t commands_execute(char *cmd, unsigned char len, bit with_checksum, unsigned char *sequence_expected);

#endif