#include <SI_EFM8BB3_Register_Enums.h>
#include "uart0.h"
#include "pwm.h"
#include "commands.h"

//  Verifica se um caracter e um digito decimal
static bit is_digit(char c)
{
    return (c >= '0') && (c <= '9');
}

//  Converte uma sequencia de caracteres ASCII numericos para inteiro
static bit parse_uint(char *s, unsigned char len, unsigned int *p_val)
{
    unsigned int v;
    unsigned char i;

    if (len == 0)
    {
        return 0;
    }

    v = 0;

    for (i = 0; i < len; i++)
    {
        if (!is_digit(s[i]))
        {
            return 0;
        }

        v = (unsigned int)(v * 10u + (s[i] - '0'));
    }

    *p_val = v;
    return 1;
}

//  Envia um caracter pela UART0 (blocking)
static void uart0_putchar_blocking(unsigned char c)
{
    while (!uart0_putchar(c));  //espera ate conseguir enviar 
    
}

//  Envia resposta de sucesso
void commands_send_ok(void)
{
    uart0_puts("OK\r\n");
}

//  Envia resposta de erro
void commands_send_err(void)
{
    uart0_puts("ERR\r\n");
}

//  Envia um nibble (4 bits) em formato hexadecimal ASCII
static void send_hex_nibble(unsigned char v)
{
    v &= 0x0F;

    if (v < 10)
    {
        uart0_putchar_blocking((unsigned char)('0' + v));
    }
    else
    {
        uart0_putchar_blocking((unsigned char)('A' + (v - 10)));
    }
}

//  Envia um byte em hexadecimal ASCII
static void send_hex_u8(unsigned char v)
{
    send_hex_nibble((unsigned char)(v >> 4));
    send_hex_nibble(v);
}


/*
   Envia uma resposta no formato:
   Tcc<dados>*hh

   O checksum e calculado sobre Tcc<dados>
*/
static void send_frame_data(char *payload, unsigned char len, bit with_checksum)
{
    unsigned char i;
    unsigned char cs;
    unsigned char c;

    cs = 0;

    // Enviar 'T' 
    c = 'T';
    uart0_putchar_blocking(c);
    cs = (unsigned char)(cs + c);

    // Enviar primeiro digito do comprimento 
    c = (unsigned char)('0' + (len / 10));
    uart0_putchar_blocking(c);
    cs = (unsigned char)(cs + c);

    // Enviar segundo digito do comprimento 
    c = (unsigned char)('0' + (len % 10));
    uart0_putchar_blocking(c);
    cs = (unsigned char)(cs + c);

    // Enviar dados �teis 
    for (i = 0; i < len; i++)
    {
        c = (unsigned char)payload[i];
        uart0_putchar_blocking(c);
        cs = (unsigned char)(cs + c);
    }

    // Campo de checksum da Fase 2 
    if (with_checksum)
    {
        uart0_putchar_blocking('*');
        send_hex_u8(cs);
    }

    uart0_puts("\r\n");
}

// Acrescenta um valor de duty-cycle em ASCII ao payload
static void append_u8_ascii(char *payload, unsigned char *p_len, unsigned char v)
{
    if (v == 100)
    {
        payload[*p_len] = '1';
        (*p_len)++;

        payload[*p_len] = '0';
        (*p_len)++;

        payload[*p_len] = '0';
        (*p_len)++;
    }
    else if (v >= 10)
    {
        payload[*p_len] = (char)('0' + (v / 10));
        (*p_len)++;

        payload[*p_len] = (char)('0' + (v % 10));
        (*p_len)++;
    }
    else
    {
        payload[*p_len] = (char)('0' + v);
        (*p_len)++;
    }
}


/*  Envia o estado atual da saida PWM e do duty
			- Se o PWM estiver ativo, envia: ONDxx
			- Se o PWM estiver inativo, envia: OFFDxx
*/
static void send_state(bit with_checksum)
{
    unsigned char d;
    unsigned char len;
    char response[8];

    d = pwm_get_duty();
    len = 0;

    if (pwm_is_on())
    {
        response[len++] = 'O';
        response[len++] = 'N';
        response[len++] = 'D';
    }
    else
    {
        response[len++] = 'O';
        response[len++] = 'F';
        response[len++] = 'F';
        response[len++] = 'D';
    }

    append_u8_ascii(response, &len, d);

    send_frame_data(response, len, with_checksum);
}

//  Interpreta e executa o comando recebido no campo <dados> da trama
command_result_t commands_execute(char *cmd, unsigned char len, bit with_checksum, unsigned char *sequence_expected)
{
    unsigned int v;
    unsigned char d;

    if (len == 0)
    {
        return COMMAND_RESULT_ERR;
    }

    switch (cmd[0])
    {
        case 'D':
            //  D? -> consulta estado
            if ((len == 2) && (cmd[1] == '?'))
            {
                send_state(with_checksum);
                return COMMAND_RESULT_OK;
            }

            //  D+ -> inc o duty
            if ((len == 2) && (cmd[1] == '+'))
            {
                d = pwm_get_duty();

                if (d < 100)
                {
                    d++;
                }

                pwm_set_duty(d);
                commands_send_ok();
                return COMMAND_RESULT_OK;
            }

            //  D- -> dec o duty
            if ((len == 2) && (cmd[1] == '-'))
            {
                d = pwm_get_duty();

                if (d > 0)
                {
                    d--;
                }

                pwm_set_duty(d);
                commands_send_ok();
                return COMMAND_RESULT_OK;
            }

            //	D0...D100 -> Define o duty
            if ((len >= 2) && (len <= 4))
            {
                if (parse_uint(&cmd[1], (unsigned char)(len - 1), &v))
                {
                    if (v <= 100)
                    {
                        pwm_set_duty((unsigned char)v);
                        commands_send_ok();
                        return COMMAND_RESULT_OK;
                    }
                }
            }

            break;

                case 'F':
									
            //  Comando Fxxx -> Define a frequencia PWM entre 100 Hz e 1000 Hz
            
            if ((len >= 4) && (len <= 5))
            {
                if (parse_uint(&cmd[1], (unsigned char)(len - 1), &v))
                {
                    if (pwm_set_freq(v))
                    {
                        commands_send_ok();
                        return COMMAND_RESULT_OK;
                    }
                }
            }

            return COMMAND_RESULT_ERR;

        case 'S':
            //   START - ativa a saida PWM
            if ((len == 5) &&
                (cmd[1] == 'T') &&
                (cmd[2] == 'A') &&
                (cmd[3] == 'R') &&
                (cmd[4] == 'T'))
            {
                pwm_start();
                commands_send_ok();
                return COMMAND_RESULT_OK;
            }

            //  STOP - desativa a saida PWM
            if ((len == 4) &&
                (cmd[1] == 'T') &&
                (cmd[2] == 'O') &&
                (cmd[3] == 'P'))
            {
                pwm_stop();
                commands_send_ok();
                return COMMAND_RESULT_OK;
            }

            // S:nn - iniciar carregamento de sequencia 
            if ((len >= 3) && (cmd[1] == ':'))
            {
                if (parse_uint(&cmd[2], (unsigned char)(len - 2), &v))
                {
                    if ((v > 0) && (v <= PWM_SEQ_MAX_POINTS))
                    {
                        pwm_sequence_clear();

                        *sequence_expected = (unsigned char)v;

                        commands_send_ok();
                        return COMMAND_RESULT_SEQUENCE_LOAD;
                    }
                }

                return COMMAND_RESULT_ERR;
            }

            // SON - inicia reproducao da sequencia
            if ((len == 3) &&
                (cmd[1] == 'O') &&
                (cmd[2] == 'N'))
            {
                if (pwm_sequence_start())
                {
                    commands_send_ok();
                    return COMMAND_RESULT_OK;
                }

                return COMMAND_RESULT_ERR;
            }

            //  SOFF - para reproducao da sequencia
            if ((len == 4) &&
                (cmd[1] == 'O') &&
                (cmd[2] == 'F') &&
                (cmd[3] == 'F'))
            {
                pwm_sequence_stop();
                commands_send_ok();
                return COMMAND_RESULT_OK;
            }

            break;

        default:
            break;
    }
		
//  Se nenhum dos comandos anteriores for reconhecido
    return COMMAND_RESULT_ERR;
}