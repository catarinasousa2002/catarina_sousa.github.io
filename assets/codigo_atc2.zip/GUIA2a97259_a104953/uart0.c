#include <SI_EFM8BB3_Register_Enums.h>
#include "uart0.h"
#include "pdata_fifo.h"

static fifo_t tx_fifo;
static fifo_t rx_fifo;

static unsigned char pdata tx_storage[FIFO_LEN];
static unsigned char pdata rx_storage[FIFO_LEN];

static bit tx_idle = 1;

void uart0_init(void)
{
    fifo_init(&tx_fifo, tx_storage);
    fifo_init(&rx_fifo, rx_storage);

    tx_idle = 1;

    SCON0_TI = 0;
    SCON0_RI = 0;

    IE_ES0 = 1;
}

bit uart0_putchar(unsigned char c)
{
    bit ok = 0;

    IE_ES0 = 0;

    if (tx_idle)
    {
        // transmissor parado - envia 
        tx_idle = 0;
        SBUF0 = c;
        ok = 1;
    }
    else
    {
        // transmissor ocupado - vai para FIFO 
        if (fifo_push_data(&tx_fifo, c) >= 0)
        {
            ok = 1;
        }
    }

    IE_ES0 = 1;
    return ok;
}

bit uart0_getchar(unsigned char *c)
{
    int ret;

    IE_ES0 = 0;
    ret = fifo_pop_data(&rx_fifo);
    IE_ES0 = 1;

    if (ret < 0)
        return 0;

    *c = (unsigned char)ret;
    return 1;
}

void uart0_isr(void) interrupt 4
{
    unsigned char c;
    int ret;

    if (SCON0_RI)
    {
        SCON0_RI = 0;
        c = SBUF0;
        fifo_push_data(&rx_fifo, c);
    }

    if (SCON0_TI)
    {
        SCON0_TI = 0;

        ret = fifo_pop_data(&tx_fifo);
        if (ret >= 0)
        {
            SBUF0 = (unsigned char)ret;
        }
        else
        {
            tx_idle = 1;
        }
    }
}


void uart0_puts(char *s)
{
    while (*s != '\0')
    {
        while (!uart0_putchar((unsigned char)*s))
        {
            ;
        }
        s++;
    }
}

