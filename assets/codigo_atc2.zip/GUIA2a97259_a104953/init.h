#ifndef INIT_H
#define INIT_H

//Fun��o principal de inicializa��o do micro
void Init_Device(void);

#endif