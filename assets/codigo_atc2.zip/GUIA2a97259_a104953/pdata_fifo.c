#include "pdata_fifo.h"

#pragma disable
char fifo_init(fifo_t *p_my_fifo, byte_t pdata *p_buffer)
{
		p_my_fifo->p_fifo = p_buffer;        // associa o buffer de mem�ria ao FIFO
		p_my_fifo->index_write = 0;          // inicializa o �ndice de escrita
		p_my_fifo->index_read = 0;           // inicializa o �ndice de leitura
		p_my_fifo->is_dead = 0;              // indica que FIFO est� ativo

		return EXIT_SUCESS;                  // retorna sucesso
}

#pragma disable
int fifo_push_data(fifo_t *p_my_fifo, char element)
{
		unsigned char len;                  // vari�vel para guardar o n�mero de elementos

		if (p_my_fifo->is_dead)             // verifica se FIFO est� desativado
				return -EPERM;                  // erro- opera��o n�o permitida

		len = p_my_fifo->index_write - p_my_fifo->index_read; // calcula o n�mero atual de elementos

		if (len > (FIFO_LEN - 1))           // verifica se FIFO est� cheio
				return -ENOBUFS;                // erro- sem espa�o dispon�vel

		p_my_fifo->p_fifo[p_my_fifo->index_write & (FIFO_LEN - 1)] = element; // escreve o elemento na posi��o correta (buffer circular)
		p_my_fifo->index_write++;           // incrementa o �ndice de escrita

		return (int)(len + 1);              // retorna o novo n�mero de elementos no FIFO
}

#pragma disable
int fifo_pop_data(fifo_t *p_my_fifo)
{
		int ret;                           // vari�vel para guardar o valor lido
		unsigned char len;                // vari�vel para guardar o n�mero de elementos

		if (p_my_fifo->is_dead)           // verifica se o FIFO est� desativado
				return -EPERM;               // erro- opera��o n�o permitida

		len = p_my_fifo->index_write - p_my_fifo->index_read; // calcula o n�mero atual de elementos

		if (len == 0)                     // verifica se o FIFO est� vazio
				return -ENODATA;              // erro- n�o h� dados dispon�veis

		ret = p_my_fifo->p_fifo[p_my_fifo->index_read & (FIFO_LEN - 1)]; // l� o elemento na posi��o correta
		p_my_fifo->index_read++;          // incrementa o �ndice de leitura

		return ret;                       // retorna o valor lido
}
/*
#pragma disable
int fifo_size(fifo_t *p_my_fifo)
{
		if (p_my_fifo->is_dead)           // verifica se FIFO est� desativado
				return -EPERM;                // erro- opera��o n�o permitida

		return (unsigned char)(p_my_fifo->index_write - p_my_fifo->index_read); // retorna o n�mero atual de elementos no FIFO
}*/
