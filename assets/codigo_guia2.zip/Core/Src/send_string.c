#include <string.h>
#include "send_string.h"
#include "usart.h"
#include "maquina_estados.h"

void write(char *str)
{
    HAL_UART_Transmit(&huart3, (uint8_t*)str, strlen(str), HAL_MAX_DELAY);
}

void write_msg(char *msg)
{
    write(msg);
    write("\r\n");
}

void UART_SendPrompt(void)
{
	write("[");
	write(StateMachine_GetStateName(state));
	write_msg("] Digite o comando:");
}
