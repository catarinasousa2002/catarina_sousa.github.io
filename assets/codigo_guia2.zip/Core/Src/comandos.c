#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "comandos.h"
#include "usart.h"
#include "maquina_estados.h"
#include "send_string.h"
#include "maquina_estados.h"
#include "encoder.h"
#include "main.h"
#include "motor.h"
#include "pid.h"

extern void Timer6_UpdatePeriod(uint16_t hw_ms);

int separa_tokens(char str[], char tokens[MAX_TOKENS][MAX_SIZE], int max_tokens)
{
    int count = 0;
    char *temp = strtok(str, " \n");

    while(temp != NULL && count < max_tokens)
    {
        if(strlen(temp) >= MAX_SIZE)
        {
            return 0;
        }

        strcpy(tokens[count], temp);
        count++;
        temp = strtok(NULL, " \n");
    }

    return count;
}

Command_t identifica_comando(char *cmd)
{
    if(strcmp(cmd, "CS") == 0) return CMD_CS;
    if(strcmp(cmd, "EN") == 0) return CMD_EN;
    if(strcmp(cmd, "HW") == 0) return CMD_HW;
    if(strcmp(cmd, "RT") == 0) return CMD_RT;
    if(strcmp(cmd, "R") == 0) return CMD_R;
    if(strcmp(cmd, "PWM") == 0) return CMD_PWM;
    if(strcmp(cmd, "RESPOS") == 0) return CMD_RESPOS;
    if(strcmp(cmd, "PID") == 0) return CMD_PID;

    return CMD_INVALID;
}

void ProcessCSCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens)
{
    if(n_tokens != 2)
    {
        write_msg("Erro: Comando invalido - CS <0-3>");
        write("\r\n");
        return;
    }

    int new_state = atoi(tokens[1]);

    if(new_state < 0 || new_state > 3)
    {
        write_msg("Erro: estado invalido");
        write("\r\n");
        return;
    }

    if(state == CONFIG_STATE)
    {
        EnterState((State_t)new_state);
        write_msg("Estado alterado");
        write("\r\n");
    }
    else if(state == MANUAL_STATE)
    {
        if(new_state == RESET_STATE || new_state == CONFIG_STATE)
        {
            EnterState((State_t)new_state);
            write_msg("Estado alterado");
            write("\r\n");
        }
        else
        {
            write_msg("Erro: Mudanca de estado invalida");
            write("\r\n");
        }
    }
    else if(state == AUTO_STATE)
    {
        if(new_state == RESET_STATE || new_state == CONFIG_STATE)
        {
            EnterState((State_t)new_state);
            write_msg("Estado alterado");
            write("\r\n");
        }
        else
        {
            write_msg("Erro: Mudanca de estado invalida");
            write("\r\n");
        }
    }
    else
    {
        write_msg("Erro: Mudanca de estado invalida");
        write("\r\n");
    }
}

void ProcessHWCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens)
{
    if(state != CONFIG_STATE)
    {
        write_msg("Erro: comando HW so permitido no estado de CONFIGURACAO");
        write("\r\n");
        return;
    }

    if(n_tokens != 2)
    {
        write_msg("Erro: sintaxe HW <1-1000>");
        write("\r\n");
        return;
    }

    int value = atoi(tokens[1]);

    if(value < 1 || value > 1000)
    {
        write_msg("Erro: valor HW invalido");
        write("\r\n");
        return;
    }

    HW = (uint16_t)value;
    Timer6_UpdatePeriod(HW);

    // ATUALIZAR PID
    PID_UpdateGains();
    PID_ResetVariables();

    write_msg("Periodo de amostragem definido para:");

    char msg[40];
    sprintf(msg, "%d ms\r\n", HW);
    write(msg);
    write("\r\n");
}

void ProcessRTCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens)
{
    if(state != CONFIG_STATE)
    {
        write_msg("Erro: comando RT so permitido no estado de CONFIGURACAO");
        write("\r\n");
        return;
    }

    if(n_tokens != 2)
    {
        write_msg("Erro: sintaxe RT <0|1|2>");
        write("\r\n");
        return;
    }

    int value = atoi(tokens[1]);

    if(value < 0 || value > 2)
    {
        write_msg("Erro: valor de RT invalido");
        write("\r\n");
        return;
    }

    RT = (uint8_t)value;

    write_msg("Tipo de leitura definido para:");

    if(RT == 0)
    {
        write_msg("POSICAO");
        write("\r\n");
    }
    else if(RT == 1)
    {
        write_msg("VELOCIDADE");
        write("\r\n");
    }
    else if(RT == 2)
    {
        write_msg("POSICAO + VELOCIDADE");
        write("\r\n");
    }
}

void ProcessENCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens)
{
    if(state != MANUAL_STATE && state != AUTO_STATE)
    {
        write_msg("Erro: comando EN so e permitido no estado MANUAL ou AUTOMATICO");
        write("\r\n");
        return;
    }

    if(n_tokens != 2)
    {
        write_msg("Erro: sintaxe EN <0|1>");
        write("\r\n");
        return;
    }

    int value = atoi(tokens[1]);

    if(value != 0 && value != 1)
    {
        write_msg("Erro: valor EN invalido");
        write("\r\n");
        return;
    }

    EN = (uint8_t)value;
    Motor_Enable(EN);

    if(EN == 1)
    {
        Motor_SetPWM(PWM_value);
        write_msg("Motor ativado");
        write("\r\n");
    }
    else
    {
        write_msg("Motor desativado");
        write("\r\n");
    }
}

void ProcessPWMCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens)
{
    if(state != CONFIG_STATE && state != MANUAL_STATE)
    {
        write_msg("Erro: Comando PWM so permitido em CONFIG ou MANUAL");
        write("\r\n");
        return;
    }

    if(n_tokens != 2)
    {
        write_msg("Erro: Comando invalido - PWM <-100..100>");
        write("\r\n");
        return;
    }

    int value = atoi(tokens[1]);

    if(value < -100 || value > 100)
    {
        write_msg("Erro: Valor PWM invalido");
        write("\r\n");
        return;
    }

    PWM_value = value;
    Motor_SetPWM(PWM_value);

    char msg[60];

    if(PWM_value < 0)
    {
        sprintf(msg, "SENTIDO REVERSE - PWM definido para (%%): %d \r\n", -PWM_value);
        write(msg);
        write("\r\n");
    }
    else if(PWM_value > 0)
    {
        sprintf(msg, "SENTIDO FORWARD - PWM definido para (%%): %d \r\n", PWM_value);
        write(msg);
        write("\r\n");
    }
    else
    {
        sprintf(msg, "PWM desligado - Definido para (%%): %d \r\n", PWM_value);
        write(msg);
        write("\r\n");
    }
}

void AdjustPWMValue(int step)
{
    if(state != MANUAL_STATE)
    {
        return;
    }

    PWM_value += step;

    if(PWM_value > 100)
    {
        PWM_value = 100;
    }

    if(PWM_value < -100)
    {
        PWM_value = -100;
    }

    Motor_SetPWM(PWM_value);

    char msg[80];
    int ccr = 0;

    if(PWM_value < 0)
    {
        ccr = Motor_GetCCRFromPercent(-PWM_value);
        sprintf(msg, "REVERSE | PWM = %d%% | CCR = %d\r\n", -PWM_value, ccr);
        write(msg);
    }
    else if(PWM_value > 0)
    {
        ccr = Motor_GetCCRFromPercent(PWM_value);
        sprintf(msg, "FORWARD | PWM = %d%% | CCR = %d\r\n", PWM_value, ccr);
        write(msg);
    }
    else
    {
        sprintf(msg, "PWM = 0%% | CCR = 0\r\n");
        write(msg);
    }
}

void ProcessRESPOSCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens)
{
    if(state != CONFIG_STATE && state != MANUAL_STATE)
    {
        write_msg("Erro: Comando RESPOS so permitido em CONFIG ou MANUAL");
        write("\r\n");
        return;
    }

    if(n_tokens != 1)
    {
        write_msg("Erro: Comando invalido - RESPOS");
        write("\r\n");
        return;
    }

    Encoder_ResetPosition();

    write_msg("Posicao reiniciada");
    write("\r\n");
}

void ShowPIDValues(void)
{
    char msg[100];
    int i, d;

    i = (int)pos_ref;
    d = (int)((pos_ref - i) * 100);
    sprintf(msg, "Pos_ref = %d.%d\r\n", i, d);
    write(msg);

    i = (int)Kp;
    d = (int)((Kp - i) * 100);
    sprintf(msg, "Kp = %d.%d\r\n", i, d);
    write(msg);

    i = (int)Ki;
    d = (int)((Ki - i) * 100);
    sprintf(msg, "Ki = %d.%d\r\n", i, d);
    write(msg);

    i = (int)Kd;
    d = (int)((Kd - i) * 100);
    sprintf(msg, "Kd = %d.%02d\r\n", i, d);
    write(msg);

    i = (int)pid_filtro;
    d = (int)((pid_filtro - i) * 100);
    sprintf(msg, "pid_filtro = %d.%d\r\n", i, d);
    write(msg);

    write("\r\n");
}

void ProcessPIDCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens)
{
    if(state != CONFIG_STATE)
    {
        write_msg("Erro: Comando PID so permitido em CONFIGURACAO");
        write("\r\n");
        return;
    }

    if(n_tokens < 2)
    {
        write_msg("Erro: Comando invalido - PID <0..5> [valor]");
        write("\r\n");
        return;
    }

    int modo = atoi(tokens[1]);

    if(modo < 0 || modo > 5)
    {
        write_msg("Erro: modo PID invalido");
        write("\r\n");
        return;
    }

    if(modo == 5)
    {
        ShowPIDValues();
        return;
    }

    if(n_tokens != 3)
    {
        write_msg("Erro: Este modo PID requer valor");
        write("\r\n");
        return;
    }

    float value = atof(tokens[2]);

    if(modo == 0)
    {
        if(value >= -50.0f && value <= 50.0f)
        {
            pos_ref = value;
            write_msg("Posicao desejada definida");
            write("\r\n");
        }
        else
        {
            write_msg("Valor da posicao desejada invalida");
            write("\r\n");
        }
    }
    else if(modo == 1)
    {
        if(value >= 0.0f && value <= 9.9f)
        {
            Kp = value;
            PID_UpdateGains();
            PID_ResetVariables();

            write_msg("Kp definido");
            write("\r\n");
        }
        else
        {
            write_msg("Valor de Kp invalido");
            write("\r\n");
        }
    }
    else if(modo == 2)
    {
        if(value >= 0.0f && value <= 25.0f)
        {
            Ki = value;
            PID_UpdateGains();
            PID_ResetVariables();

            write_msg("Ki definido");
            write("\r\n");
        }
        else
        {
            write_msg("Valor de Ki invalido");
            write("\r\n");
        }
    }
    else if(modo == 3)
    {
        if(value >= 0.00f && value <= 9.9f)
        {
            Kd = value;
            PID_UpdateGains();
            PID_ResetVariables();

            write_msg("Kd definido");
            write("\r\n");
        }
        else
        {
            write_msg("Valor de Kd invalido");
            write("\r\n");
        }
    }
    else if(modo == 4)
    {
        if(value >= 0.0f && value <= 1.0f)
        {
            pid_filtro = value;
            PID_UpdateGains();
            PID_ResetVariables();

            write_msg("Constante do filtro PID definida");
            write("\r\n");
        }
        else
        {
            write_msg("Valor da constante do filtro PID invalida");
            write("\r\n");
        }
    }
}

void ProcessRCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens)
{
    if(state != MANUAL_STATE)
    {
        write_msg("Erro: Comando R so permitido em MANUAL");
        write("\r\n");
        return;
    }

    if(n_tokens < 2)
    {
        write_msg("Erro: Comando invalido - R <modo>");
        write("\r\n");
        return;
    }

    int modo = atoi(tokens[1]);

    if(modo == 0)
    {
        ENL = 0;
        write_msg("Leitura parada");
        write("\r\n");
    }
    else if(modo == 1)
    {
    	ENL = 1;
    	count = 0;
    	N = 0;

        write_msg("Leitura continua iniciada");

        char msg[50];
        sprintf(msg, "Periodo de amostragem - HW = %d ms\r\n", HW);
        write(msg);
        write("\r\n");
    }
    else if(modo == 2)
    {
        if(n_tokens != 3)
        {
            write_msg("Erro: R 2 requer numero de amostras");
            write("\r\n");
            return;
        }

        N = atoi(tokens[2]);

        if(N <= 0 || N > 1000)
        {
            write_msg("Erro: Numero de amostras invalido");
            write("\r\n");
            return;
        }

        ENL = 1;
        count = 0;

        write_msg("Leitura limitada iniciada");

        char msg[50];
        sprintf(msg, "Periodo de amostragem - HW = %d ms\r\n", HW);
        write(msg);

        sprintf(msg, "Numero de amostras = %d\r\n", N);
        write(msg);
        write("\r\n");
    }
    else
    {
        write_msg("Erro: modo R invalido");
        write("\r\n");
    }
}

void ProcessCommand(char *linha)
{
    char tokens[MAX_TOKENS][MAX_SIZE];
    int n_tokens = separa_tokens(linha, tokens, MAX_TOKENS);

    if(n_tokens == 0)
    {
        write_msg("Erro: Comando invalido");
        write("\r\n");
        return;
    }

    Command_t cmd = identifica_comando(tokens[0]);

    switch(cmd)
    {
        case CMD_CS:
            ProcessCSCommand(tokens, n_tokens);
            break;

        case CMD_HW:
            ProcessHWCommand(tokens, n_tokens);
            break;

        case CMD_RT:
            ProcessRTCommand(tokens, n_tokens);
            break;

        case CMD_EN:
            ProcessENCommand(tokens, n_tokens);
            break;

        case CMD_PWM:
            ProcessPWMCommand(tokens, n_tokens);
            break;

        case CMD_RESPOS:
            ProcessRESPOSCommand(tokens, n_tokens);
            break;

        case CMD_R:
            ProcessRCommand(tokens, n_tokens);
            break;

        case CMD_PID:
            ProcessPIDCommand(tokens, n_tokens);
            break;

        default:
            write_msg("Comando invalido");
            write("\r\n");
            break;
    }
}
