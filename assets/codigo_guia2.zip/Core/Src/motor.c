#include "motor.h"
#include "tim.h"
#include "gpio.h"

#define PWM_MAX 100
#define PWM_PERIOD 999

static uint8_t motor_enabled = 0;

static uint32_t PWM_PercentToCCR(int duty_percent)
{
    if (duty_percent < 0)
        duty_percent = 0;

    if (duty_percent > 100)
        duty_percent = 100;

    return (duty_percent * (PWM_PERIOD + 1)) / 100;
}

int Motor_GetCCRFromPercent(int duty_percent)
{
    return (int)PWM_PercentToCCR(duty_percent);
}

void Motor_Init(void)
{
    motor_enabled = 0;

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET); // R_EN = 0
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET); // L_EN = 0

    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 0); // RPWM = 0
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, 0); // LPWM = 0
}

void Motor_Enable(uint8_t value)
{
    if (value == 0)
    {
        motor_enabled = 0;

        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);

        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 0);
        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, 0);
    }
    else
    {
        motor_enabled = 1;

        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);
    }
}

void Motor_SetPWM(int pwm)
{
    uint32_t ccr = 0;
    int duty = 0;

    if (pwm > PWM_MAX)
        pwm = PWM_MAX;

    if (pwm < -PWM_MAX)
        pwm = -PWM_MAX;

    if (motor_enabled == 0)
    {
        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 0);
        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, 0);
        return;
    }

    if (pwm > 0)
    {
        duty = pwm;
        ccr = PWM_PercentToCCR(duty);

        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, ccr); // RPWM
        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, 0);   // LPWM
    }
    else if (pwm < 0)
    {
        duty = -pwm;
        ccr = PWM_PercentToCCR(duty);

        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 0);   // RPWM
        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, ccr); // LPWM
    }
    else
    {
        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 0);
        __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, 0);
    }
}

void Motor_Stop(void)
{
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, 0);
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_2, 0);
}
