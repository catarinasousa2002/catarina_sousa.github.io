#include "maquina_estados.h"
#include "send_string.h"
#include "motor.h"
#include "pid.h"

State_t state = RESET_STATE;

uint8_t EN = 0;
uint16_t HW = 10;
uint8_t RT = 0;
int PWM_value = 0;

float Kp = 0;
float Ki = 0;
float Kd = 0;
float pid_filtro = 0;
float pos_ref = 0;

uint8_t ENL = 0;     // enable leitura
uint16_t N = 0;      // número de amostras
uint16_t count = 0;  // contador de amostras

void StateMachine_ResetVariables(void)
{
    EN = 0;
    HW = 10;
    RT = 0;
    PWM_value = 0;

    Kp = 0;
    Ki = 0;
    Kd = 0;
    pid_filtro = 0;
    pos_ref = 0;
}

void EnterState(State_t new_state)
{
    state = new_state;

    switch(state)
    {
        case RESET_STATE:
            ENL = 0;
            Motor_Enable(0);
            Motor_SetPWM(0);
            break;

        case CONFIG_STATE:
            EN = 0;
            ENL = 0;
            Motor_Enable(0);
            Motor_SetPWM(0);
            break;

        case MANUAL_STATE:
            break;

        case AUTO_STATE:
            EN = 1;
            Motor_Enable(1);
            //Motor_SetPWM(PWM_value);
            PID_UpdateGains();
            PID_ResetVariables();
            break;

        default:
            state = RESET_STATE;
            EN = 0;
            ENL = 0;
            PWM_value = 0;
            Motor_Enable(0);
            Motor_SetPWM(0);
            break;
    }
}

void StateMachine_Run(void)
{
    switch(state)
    {
        case RESET_STATE:
            write_msg("A fazer reset...");
            write("\r\n");
            StateMachine_ResetVariables();
            EnterState(CONFIG_STATE);
            break;

        case CONFIG_STATE:
            break;

        case MANUAL_STATE:
            break;

        case AUTO_STATE:
            if(EN == 0)
            {
                write_msg("Motor desativado. A voltar para CONFIGURACAO");
                write("\r\n");
                EnterState(CONFIG_STATE);
            }
            else
            {
                /* executar controlo PID */
            }
            break;

        default:
            EnterState(RESET_STATE);
            break;
    }
}

char* StateMachine_GetStateName(State_t current_state)
{
    switch(current_state)
    {
        case RESET_STATE:
            return "RESET";

        case CONFIG_STATE:
            return "CONFIGURACAO";

        case MANUAL_STATE:
            return "LEITURA/MANUAL";

        case AUTO_STATE:
            return "AUTOMATICO";

        default:
            return "DESCONHECIDO";
    }
}
