#include "encoder.h"
#include "send_string.h"
#include <stdio.h>

volatile long encoder_count = 0;
volatile float position_rad = 0.0f;
volatile float position_deg = 0.0f;
volatile long encoder_count_prev = 0;
volatile long delta_pulses = 0;
volatile float velocity_rad_s = 0.0f;
volatile float velocity_rpm = 0.0f;

void Encoder_UpdatePosition(void)
{
    position_rad = encoder_count * (2.0f * 3.1416f / 960.0f);
    position_deg = encoder_count * (360.0f / 960.0f);
}

void Encoder_ResetPosition(void)
{
    encoder_count = 0;
    position_rad = 0.0f;
    position_deg = 0.0f;
}

void Encoder_HandlePulse(void)
{
    if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_3) == GPIO_PIN_RESET)
    {
        if(encoder_count > -19200)
            encoder_count--;
    }
    else
    {
        if(encoder_count < 19200)
            encoder_count++;
    }
}

void Encoder_PrintPosition(void)
{
    char msg[100];

    int i;
    int d;


    // RAD
    i = (int)position_rad;
    d = (int)((position_rad - i) * 10000);
    sprintf(msg, "Posicao = %d.%04d rad\r\n", i, d);
    write(msg);

    // GRAUS
    i = (int)position_deg;
    d = (int)((position_deg - i) * 100);
    sprintf(msg, "Posicao = %d.%02d graus\r\n", i, d);
    write(msg);

    write("\r\n");
}

void Encoder_UpdateVelocity(uint16_t hw_ms)
{
    float Ts;

    Ts = hw_ms / 1000.0f;

    delta_pulses = encoder_count - encoder_count_prev;
    encoder_count_prev = encoder_count;

    velocity_rad_s = (delta_pulses * 2.0f * 3.1416f) / (960.0f * Ts);
    velocity_rpm = (velocity_rad_s * 60.0f) / (2.0f * 3.1416f);
}

void Encoder_PrintVelocity(void)
{
    char msg[100];
    int i, d;


    i = (int)velocity_rad_s;
    d = (int)((velocity_rad_s - i) * 10000);
    if(d < 0) d = -d;
    sprintf(msg, "Velocidade = %d.%04d rad/s\r\n", i, d);
    write(msg);

    i = (int)velocity_rpm;
    d = (int)((velocity_rpm - i) * 100);
    if(d < 0) d = -d;
    sprintf(msg, "Velocidade = %d.%02d rpm\r\n", i, d);
    write(msg);

    write("\r\n");
}

void Encoder_PrintReadings(uint8_t rt_mode)
{
    if(rt_mode == 0)
    {
        Encoder_PrintPosition();
    }
    else if(rt_mode == 1)
    {
        Encoder_PrintVelocity();
    }
    else if(rt_mode == 2)
    {
        Encoder_PrintPosition();
        Encoder_PrintVelocity();
    }
}
