#include "pid.h"
#include "main.h"
#include "send_string.h"

// Variaveis definidas noutros modulos
extern float Kp;
extern float Ki;
extern float Kd;
extern float pid_filtro;
extern uint16_t HW;
extern float pos_ref;
extern float position_rad;

// MODO DE TESTE OBJETIVO 6
// 0 = modo normal
// 1 = modo teste
int pid_test_mode = 0;

// 1 = onda quadrada
// 2 = onda triangular
int pid_test_signal_type = 1;

float pid_test_input = 0.0f;
static uint16_t pid_test_index = 0;

// Variaveis internas do PID
float e = 0.0f;
float e_ant = 0.0f;

float y = 0.0f;
float y_ant = 0.0f;

float sum_e = 0.0f;
float sum_e_bkp = 0.0f;

float u = 0.0f;
float u_d = 0.0f;
float u_d_ant = 0.0f;

// Ganhos discretos
float Kp_h = 0.0f;
float Ki_h = 0.0f;
float Kd_h = 0.0f;

// Saturacao da saida
float U_sat_a = 6.0f;
float U_sat_b = -6.0f;

// PWM calculado pelo PID
int pid_pwm_value = 0;

static const float square_wave[50] = {
    0,0,0,0,0, 2,2,2,2,2,
    2,2,2,2,2, 0,0,0,0,0,
    0,0,0,0,0, 2,2,2,2,2,
    2,2,2,2,2, 0,0,0,0,0,
    0,0,0,0,0, 2,2,2,2,2
};

static const float triangular_wave[50] = {
    1.0f,1.2f,1.4f,1.6f,1.8f,
    2.0f,1.8f,1.6f,1.4f,1.2f,
    1.0f,0.8f,0.6f,0.4f,0.2f,
    0.0f,0.2f,0.4f,0.6f,0.8f,
    1.0f,1.2f,1.4f,1.6f,1.8f,
    2.0f,1.8f,1.6f,1.4f,1.2f,
    1.0f,0.8f,0.6f,0.4f,0.2f,
    0.0f,0.2f,0.4f,0.6f,0.8f,
    1.0f,1.2f,1.4f,1.6f,1.8f,
    2.0f,1.8f,1.6f,1.4f,1.2f
};

void PID_PrintDebug(void)
{
    char msg[120];
    sprintf(msg, "y=%.3f e=%.3f u=%.3f\r\n", y, e, u);
    write(msg);
}

void PID_ResetVariables(void)
{
    if(pid_test_mode == 1)
    {
        y = pid_test_input;
        y_ant = pid_test_input;
    }
    else
    {
        y = position_rad;
        y_ant = position_rad;
    }

    e = 0.0f;
    e_ant = 0.0f;

    sum_e = 0.0f;
    sum_e_bkp = 0.0f;

    u = 0.0f;
    u_d = 0.0f;
    u_d_ant = 0.0f;

    pid_pwm_value = 0;
    pid_test_index = 0;

    U_sat_a = 6.0f;
    U_sat_b = -6.0f;
}

void PID_UpdateGains(void)
{
    float h;

    h = HW / 1000.0f;   // HW em ms -> h em segundos

    if(h <= 0.0f)
    {
        h = 0.01f;
    }

    Kp_h = Kp;
    Ki_h = Ki * h;
    Kd_h = (Kd * (1.0f - pid_filtro)) / h;
}

void PID_TestNextSample(void)
{
    if(pid_test_mode == 0)
    {
        return;
    }

    if(pid_test_signal_type == 1)
    {
        pid_test_input = square_wave[pid_test_index];
    }
    else
    {
        pid_test_input = triangular_wave[pid_test_index];
    }

    pid_test_index++;

    if(pid_test_index >= 50)
    {
        pid_test_index = 0;
    }
}

void PID_Compute(void)
{
    // 1) Ler a variavel medida
	if(pid_test_mode == 1)
	{
	    y = pid_test_input;
	}
	else
	{
	    y = position_rad;
	}

    // 2) Calcular erro
    e = pos_ref - y;

    // 3) Guardar somatorio antes de atualizar
    sum_e_bkp = sum_e;

    // 4) Atualizar somatorio dos erros
    sum_e = sum_e + e_ant;

    // 5) Calcular componente derivativa filtrada
    u_d = Kd_h * (y - y_ant) + pid_filtro * u_d_ant;

    // 6) Calcular comando total
    u = Kp_h * e + Ki_h * sum_e - u_d;

    // 7) Atualizar valores anteriores
    e_ant = e;
    y_ant = y;
    u_d_ant = u_d;

    // 8) Saturacao
    if(u > U_sat_a)
    {
        u = U_sat_a;
        sum_e = sum_e_bkp;
    }
    else if(u < U_sat_b)
    {
        u = U_sat_b;
        sum_e = sum_e_bkp;
    }

    // 9) Converter u (V) para PWM (%)
    pid_pwm_value = (int)((u / 6.0f) * 100.0f);

    if(pid_pwm_value > 100)
    {
        pid_pwm_value = 100;
    }
    else if(pid_pwm_value < -100)
    {
        pid_pwm_value = -100;
    }
}
