
#ifndef INC_ENCODER_H_
#define INC_ENCODER_H_

#include "main.h"

extern volatile long encoder_count;
extern volatile float position_rad;
extern volatile float position_deg;
extern volatile long encoder_count_prev;
extern volatile long delta_pulses;
extern volatile float velocity_rad_s;
extern volatile float velocity_rpm;

void Encoder_PrintVelocity(void);
void Encoder_PrintReadings(uint8_t rt_mode);
void Encoder_UpdateVelocity(uint16_t hw_ms);
void Encoder_PrintVelocity(void);
void Encoder_HandlePulse(void);
void Encoder_UpdatePosition(void);
void Encoder_ResetPosition(void);
void Encoder_PrintPosition(void);

#endif /* INC_ENCODER_H_ */
