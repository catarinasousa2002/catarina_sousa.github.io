#ifndef INC_MAQUINA_ESTADOS_H_
#define INC_MAQUINA_ESTADOS_H_
#include <stdint.h>

typedef enum
{
    RESET_STATE = 0,
    CONFIG_STATE,
    MANUAL_STATE,
    AUTO_STATE

} State_t;

extern State_t state;

extern uint8_t EN;
extern uint16_t HW;
extern uint8_t RT;
extern int PWM_value;

extern float Kp;
extern float Ki;
extern float Kd;
extern float pid_filtro;
extern float pos_ref;
extern uint8_t ENL;     // enable leitura
extern uint16_t N;      // número de amostras
extern uint16_t count;  // contador de amostras

void StateMachine_Run(void);
void StateMachine_ResetVariables(void);
char* StateMachine_GetStateName(State_t current_state);
void EnterState(State_t new_state);


#endif /* INC_MAQUINA_ESTADOS_H_ */
