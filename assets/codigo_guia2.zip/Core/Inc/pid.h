#ifndef INC_PID_H_
#define INC_PID_H_

#include <stdint.h>

extern int pid_pwm_value;
extern int pid_test_mode;
extern int pid_test_signal_type;
extern float pid_test_input;
extern float y;
extern float u;

void PID_ResetVariables(void);
void PID_UpdateGains(void);
void PID_Compute(void);
void PID_TestNextSample(void);

#endif /* INC_PID_H_ */
