

#ifndef INC_MOTOR_H_
#define INC_MOTOR_H_

#include "main.h"
#include <stdint.h>

void Motor_Init(void);
void Motor_Enable(uint8_t value);
void Motor_SetPWM(int pwm);
void Motor_Stop(void);
int Motor_GetCCRFromPercent(int duty_percent);


#endif /* INC_MOTOR_H_ */
