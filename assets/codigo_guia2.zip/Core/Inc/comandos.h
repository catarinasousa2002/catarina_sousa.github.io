#ifndef INC_COMANDOS_H_
#define INC_COMANDOS_H_

#define MAX_TOKENS  5
#define MAX_SIZE    20

typedef enum
{
    CMD_CS,
    CMD_EN,
    CMD_HW,
    CMD_RT,
    CMD_R,
    CMD_PWM,
    CMD_RESPOS,
    CMD_PID,
    CMD_INVALID

} Command_t;

int separa_tokens(char str[], char tokens[MAX_TOKENS][MAX_SIZE], int max_tokens);
Command_t identifica_comando(char *cmd);
void ProcessCommand(char *linha);
void ProcessCSCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens);
void ProcessHWCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens);
void ProcessRTCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens);
void ProcessENCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens);
void ProcessPWMCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens);
void ProcessRESPOSCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens);
void ProcessRCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens);
void ProcessPIDCommand(char tokens[MAX_TOKENS][MAX_SIZE], int n_tokens);
void AdjustPWMValue(int step);



#endif /* INC_COMANDOS_H_ */
