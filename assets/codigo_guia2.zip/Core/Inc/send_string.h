
#ifndef INC_SEND_STRING_H_
#define INC_SEND_STRING_H_

void UART_SendString(char *str);
void UART_SendPrompt(void);
void write_msg(char *msg);
void write(char *msg);

#endif /* INC_SEND_STRING_H_ */
