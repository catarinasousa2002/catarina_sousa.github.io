#include "robot_motion.h"

void Robot_LineForward(void)
{
    Motor_SetLeftSpeed(600);  // define a velocidade do motor esquerdo para avançar
    Motor_SetRightSpeed(550); // define a velocidade do motor direito para avançar
}

void Robot_LineLeft(void)
{
    Motor_SetLeftSpeed(150);  // reduz bastante a velocidade do motor esquerdo
    Motor_SetRightSpeed(850); // aumenta a velocidade do motor direito para virar à esquerda
}

void Robot_LineRight(void)
{
    Motor_SetLeftSpeed(850);  // aumenta a velocidade do motor esquerdo para virar à direita
    Motor_SetRightSpeed(150); // reduz bastante a velocidade do motor direito
}

void Robot_Stop(void)
{
    Motor_Stop(); // chama a função que para os dois motores
}
