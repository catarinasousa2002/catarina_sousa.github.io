#include "sensor_ultrassonico.h"

#define TRIG_PORT TRIGGER_US_GPIO_Port //porto do pino TRIG
#define TRIG_PIN  TRIGGER_US_Pin       //pino TRIG

#define ECHO_PORT ECHO_US_GPIO_Port    //porto do pino ECHO
#define ECHO_PIN  ECHO_US_Pin          //pino ECHO

void Ultrasonic_Init(void)
{
    HAL_TIM_Base_Start(&htim2); // inicia o timer usado para medir tempos
}

static void delay_us(uint16_t us)
{
    __HAL_TIM_SET_COUNTER(&htim2, 0);           //coloca o contador do timer a zero
    while (__HAL_TIM_GET_COUNTER(&htim2) < us); //espera até passar o tempo pretendido
}

float Ultrasonic_GetDistance_cm(void)
{
    uint32_t pulse_time; // variável para guardar o tempo do pulso ECHO

    HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_RESET); //garantir que TRIG começa a 0
    delay_us(2);                                            //espera 2us

    HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_SET);   //TRIG = 1
    delay_us(10);                                           //mantém o pulso durante 10us
    HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_RESET); //volta a colocar o TRIG a 0

    __HAL_TIM_SET_COUNTER(&htim2, 0); //reinicia o contador para esperar pelo ECHO

    while (HAL_GPIO_ReadPin(ECHO_PORT, ECHO_PIN) == GPIO_PIN_RESET) //espera até o ECHO passar a 1
    {
        if (__HAL_TIM_GET_COUNTER(&htim2) > 30000) // verifica se passou demasiado tempo
            return -1.0f;                          // erro, nao recebeu echo
    }

    __HAL_TIM_SET_COUNTER(&htim2, 0); //reinicia o contador para medir a duração do ECHO

    while (HAL_GPIO_ReadPin(ECHO_PORT, ECHO_PIN) == GPIO_PIN_SET) // mede enquanto o ECHO está a 1
    {
        if (__HAL_TIM_GET_COUNTER(&htim2) > 30000) // verifica se o pulso durou demasiado tempo
            return -2.0f;                          // erro, eco demasiado longo
    }

    pulse_time = __HAL_TIM_GET_COUNTER(&htim2); // guarda o tempo medido do pulso

    return pulse_time / 58.0f; // converte o tempo do eco (us) em distância (cm)
}
