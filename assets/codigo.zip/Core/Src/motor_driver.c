#include "motor_driver.h"

#define PWM_MAX 999 //valor máximo do PWM

void Motor_Init(void)
{
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1); //inicia o PWM do canal ENA
    HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2); //inicia o PWM do canal ENB

    Motor_Stop(); //motores começam parados
}

static int LimitSpeed(int speed)
{
    if (speed > PWM_MAX) return PWM_MAX;   // limita a velocidade máxima positiva
    if (speed < -PWM_MAX) return -PWM_MAX; // limita a velocidade máxima negativa
    return speed;                          // devolve a velocidade
}

void Motor_SetLeftSpeed(int speed)
{
    speed = LimitSpeed(speed); //limita o valor recebido

    if (speed > 0)
    {
        HAL_GPIO_WritePin(MOTOR_IN3_GPIO_Port, MOTOR_IN3_Pin, GPIO_PIN_SET);   // define o sentido para a frente
        HAL_GPIO_WritePin(MOTOR_IN4_GPIO_Port, MOTOR_IN4_Pin, GPIO_PIN_RESET); // reset do outro sentido
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, speed);                   // aplica o PWM ao motor esquerdo
    }
    else if (speed < 0)
    {
        HAL_GPIO_WritePin(MOTOR_IN3_GPIO_Port, MOTOR_IN3_Pin, GPIO_PIN_RESET); // define o sentido inverso
        HAL_GPIO_WritePin(MOTOR_IN4_GPIO_Port, MOTOR_IN4_Pin, GPIO_PIN_SET);
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, -speed);                  // aplica o PWM com valor positivo
    }
    else
    {
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0); // para o motor esquerdo
    }
}

void Motor_SetRightSpeed(int speed)
{
    speed = LimitSpeed(speed); // limita o valor recebido

    if (speed > 0)
    {
        HAL_GPIO_WritePin(MOTOR_IN1_GPIO_Port, MOTOR_IN1_Pin, GPIO_PIN_SET);   // define o sentido para a frente
        HAL_GPIO_WritePin(MOTOR_IN2_GPIO_Port, MOTOR_IN2_Pin, GPIO_PIN_RESET);
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, speed);                   // aplica o PWM ao motor direito
    }
    else if (speed < 0)
    {
        HAL_GPIO_WritePin(MOTOR_IN1_GPIO_Port, MOTOR_IN1_Pin, GPIO_PIN_RESET); // define o sentido inverso
        HAL_GPIO_WritePin(MOTOR_IN2_GPIO_Port, MOTOR_IN2_Pin, GPIO_PIN_SET);
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, -speed);                  // aplica o PWM com valor positivo
    }
    else
    {
        __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0); // para o motor direito
    }
}

void Motor_Stop(void)
{
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0); //PWM do motor direito a zero
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, 0); //PWM do motor esquerdo a zero

    HAL_GPIO_WritePin(MOTOR_IN1_GPIO_Port, MOTOR_IN1_Pin, GPIO_PIN_RESET); //desativa o pino IN1
    HAL_GPIO_WritePin(MOTOR_IN2_GPIO_Port, MOTOR_IN2_Pin, GPIO_PIN_RESET); //desativa o pino IN2
    HAL_GPIO_WritePin(MOTOR_IN3_GPIO_Port, MOTOR_IN3_Pin, GPIO_PIN_RESET); //desativa o pino IN3
    HAL_GPIO_WritePin(MOTOR_IN4_GPIO_Port, MOTOR_IN4_Pin, GPIO_PIN_RESET); //desativa o pino IN4
}
