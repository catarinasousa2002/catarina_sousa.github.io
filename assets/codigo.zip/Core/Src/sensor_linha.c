#include "sensor_linha.h"

#define TH_IR1 2500
#define TH_IR2 2500
#define TH_IR3 2500
#define TH_IR4 2500
#define TH_IR5 2500

static uint16_t ir_values[NUM_IR_SENSORS];
static uint8_t line[NUM_IR_SENSORS];

//lê um canal específico do ADC1 e devolve o valor convertido
static uint16_t Read_ADC_Channel(uint32_t channel)             //recebe o canal a ler
{
    ADC_ChannelConfTypeDef sConfig = {0};             //estrutura de configuração para o canal ADC

    sConfig.Channel = channel;							//canal ADC a ser lido
    sConfig.Rank = ADC_REGULAR_RANK_1;                  //primeira conversão
    sConfig.SamplingTime = ADC_SAMPLETIME_64CYCLES_5;   //tempo de amostragem
    sConfig.SingleDiff = ADC_SINGLE_ENDED;				//tensão do pino em relação ao GND
    sConfig.OffsetNumber = ADC_OFFSET_NONE;
    sConfig.Offset = 0;

    HAL_ADC_ConfigChannel(&hadc1, &sConfig);            //aplica esta configuração ao ADC1

    HAL_ADC_Start(&hadc1); 								//inicia a conversão ADC

    //Espera até a conversão terminar, com timeout de 100 ms
    if (HAL_ADC_PollForConversion(&hadc1, 100) == HAL_OK)
    {
        uint16_t value = HAL_ADC_GetValue(&hadc1);   //obtem o valor convertido
        HAL_ADC_Stop(&hadc1);					     //para o ADC e retorna o valor lido
        return value;
    }

    HAL_ADC_Stop(&hadc1); //se a conversão falhar, devolve 9999 como valor de erro, porque está fora da gama do ADC
    return 9999;
}

/*
Lê os 5 sensores infravermelhos através do ADC1
Cada sensor é lido num canal ADC diferente
Os valores obtidos são guardados no array ir_values[]
*/
void LineSensor_Read(void)
{
    ir_values[0] = Read_ADC_Channel(ADC_CHANNEL_16);
    ir_values[1] = Read_ADC_Channel(ADC_CHANNEL_15);
    ir_values[2] = Read_ADC_Channel(ADC_CHANNEL_18);
    ir_values[3] = Read_ADC_Channel(ADC_CHANNEL_19);
    ir_values[4] = Read_ADC_Channel(ADC_CHANNEL_3);
}

/*
Compara cada valor analógico com o limite
Se o valor lido for inferior ao limite, assume linha preta
O resultado é guardado no array line[], com valores 0 ou 1
*/
void LineSensor_ConvertToDigital(void)
{
    line[0] = (ir_values[0] < TH_IR1);
    line[1] = (ir_values[1] < TH_IR2);
    line[2] = (ir_values[2] < TH_IR3);
    line[3] = (ir_values[3] < TH_IR4);
    line[4] = (ir_values[4] < TH_IR5);
}

/*
Devolve o array com os valores analógicos lidos dos sensores IR
Usado para calibrar os limites
*/
uint16_t* LineSensor_GetAnalogValues(void)
{
    return ir_values;
}

/*
Devolve o array digital line[]
É utilizado para decidir se o robô deve avançar, corrigir para a esquerda, corrigir para a direita ou parar
*/

uint8_t* LineSensor_GetDigitalValues(void)
{
    return line;
}

