
#ifndef INC_SENSOR_LINHA_H_
#define INC_SENSOR_LINHA_H_
#include "main.h"
#include "adc.h"

#define NUM_IR_SENSORS 5


void LineSensor_Read(void);
void LineSensor_ConvertToDigital(void);

uint16_t* LineSensor_GetAnalogValues(void);
uint8_t* LineSensor_GetDigitalValues(void);

#endif

