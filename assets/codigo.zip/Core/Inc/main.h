/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED_OBS_Pin GPIO_PIN_7
#define LED_OBS_GPIO_Port GPIOF
#define IR1_Pin GPIO_PIN_0
#define IR1_GPIO_Port GPIOA
#define IR2_Pin GPIO_PIN_3
#define IR2_GPIO_Port GPIOA
#define IR3_Pin GPIO_PIN_4
#define IR3_GPIO_Port GPIOA
#define IR4_Pin GPIO_PIN_5
#define IR4_GPIO_Port GPIOA
#define IR5_Pin GPIO_PIN_6
#define IR5_GPIO_Port GPIOA
#define TRIGGER_US_Pin GPIO_PIN_2
#define TRIGGER_US_GPIO_Port GPIOB
#define ECHO_US_Pin GPIO_PIN_10
#define ECHO_US_GPIO_Port GPIOB
#define MOTOR_PWM1_Pin GPIO_PIN_6
#define MOTOR_PWM1_GPIO_Port GPIOC
#define MOTOR_PWM2_Pin GPIO_PIN_7
#define MOTOR_PWM2_GPIO_Port GPIOC
#define MOTOR_IN1_Pin GPIO_PIN_8
#define MOTOR_IN1_GPIO_Port GPIOC
#define MOTOR_IN2_Pin GPIO_PIN_9
#define MOTOR_IN2_GPIO_Port GPIOC
#define MOTOR_IN3_Pin GPIO_PIN_10
#define MOTOR_IN3_GPIO_Port GPIOC
#define MOTOR_IN4_Pin GPIO_PIN_11
#define MOTOR_IN4_GPIO_Port GPIOC

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
