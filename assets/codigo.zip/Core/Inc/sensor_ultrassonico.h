#ifndef INC_SENSOR_ULTRASSONICO_H_
#define INC_SENSOR_ULTRASSONICO_H_


#include "main.h"
#include "tim.h"
#define OBSTACLE_DISTANCE_CM 15.0f

void Ultrasonic_Init(void);
float Ultrasonic_GetDistance_cm(void);

#endif

