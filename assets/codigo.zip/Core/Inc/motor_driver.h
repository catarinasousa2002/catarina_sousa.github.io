#ifndef INC_MOTOR_DRIVER_H_
#define INC_MOTOR_DRIVER_H_

#include "main.h"
#include "tim.h"

void Motor_Init(void);
void Motor_SetLeftSpeed(int speed);
void Motor_SetRightSpeed(int speed);
void Motor_Stop(void);

#endif
