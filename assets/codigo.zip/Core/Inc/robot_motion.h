#ifndef INC_ROBOT_MOTION_H_
#define INC_ROBOT_MOTION_H_


#include "main.h"
#include "motor_driver.h"

void Robot_LineForward(void);
void Robot_LineLeft(void);
void Robot_LineRight(void);
void Robot_Stop(void);


#endif


